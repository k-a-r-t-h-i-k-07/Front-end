package com.attendanceTracking;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AttendanceTrackingApplicationTests {

	@Test
	void contextLoads() {
	}

}
